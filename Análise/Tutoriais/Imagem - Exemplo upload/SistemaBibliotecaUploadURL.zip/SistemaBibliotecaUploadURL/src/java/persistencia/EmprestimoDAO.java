/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package persistencia;

import java.util.List;
import modelo.Emprestimo;
import org.hibernate.Session;

/**
 *
 * @author jezer
 */
public class EmprestimoDAO {

    public void salvar(Emprestimo emprestimo)
        {
        Session sessao = HibernateUtil.getSessionFactory().getCurrentSession();
        sessao.saveOrUpdate(emprestimo);
        }
    
    public List<Emprestimo> listar() {
        Session sessao = HibernateUtil.getSessionFactory().getCurrentSession();
        return sessao.createCriteria(Emprestimo.class).list();
    }
}
