package persistencia;

import java.util.List;
import modelo.Autor;
import org.hibernate.Session;

public class AutorDAO {
    
    
    public void salvar(Autor l) {
        Session sessao = HibernateUtil.getSessionFactory().getCurrentSession();
        sessao.saveOrUpdate(l);
    }
    
    public Autor carregar(int id) {
        Session sessao = HibernateUtil.getSessionFactory().getCurrentSession();
        return (Autor) sessao.load(Autor.class, id);
    }
    
    public void remover(Autor l) {
        Session sessao = HibernateUtil.getSessionFactory().getCurrentSession();
        sessao.delete(l);
    }
    
    public List<Autor> listar() {
        Session sessao = HibernateUtil.getSessionFactory().getCurrentSession();
        return sessao.createCriteria(Autor.class).list();
    }
}
