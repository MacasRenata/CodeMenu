package persistencia;

import beans.SessaoUsuarioBean;
import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import modelo.Usuario;
import org.hibernate.Query;
import org.hibernate.Session;

public class UsuarioDAO {
//INSERT INTO usuarios (id, cpf, email, nome, telefone, login, senha) VALUES (1, '25641564564', 'asd@safd.ver', 'admin', '(56) 45645-6456', 'admin',SHA2('1234',256));
//INSERT INTO professor (id_usuario,disciplina) VALUES (1, 'admin');
    
    public static String hashSenha(String senha){
        try {
            MessageDigest algorithm = MessageDigest.getInstance("SHA-256");
            byte messageDigest[] = algorithm.digest(senha.getBytes("UTF-8"));
            StringBuilder hexString = new StringBuilder();
            for (byte b : messageDigest) 
                hexString.append(String.format("%02X", 0xFF & b));
            return  hexString.toString();
        } catch (NoSuchAlgorithmException | UnsupportedEncodingException ex) {
            Logger.getLogger(SessaoUsuarioBean.class.getName()).log(
                    Level.SEVERE, null, ex);
        }
    return null;
    }
   
    
    public void salvar(Usuario usuario) {
        Session sessao = HibernateUtil.getSessionFactory().getCurrentSession();
        sessao.saveOrUpdate(usuario);
    }
    
    public Usuario carregar(int id) {
        Session sessao = HibernateUtil.getSessionFactory().getCurrentSession();
        return (Usuario) sessao.get(Usuario.class, id);
    }
    
    public void remover(Usuario usuario) {
        Session sessao = HibernateUtil.getSessionFactory().getCurrentSession();
        sessao.delete(usuario);
    }
    
    public List<Usuario> listar() {
        Session sessao = HibernateUtil.getSessionFactory().getCurrentSession();
        return sessao.createQuery("from Usuario").list();
    }
    
    public void merge(Usuario usuario) {
        Session sessao = HibernateUtil.getSessionFactory().getCurrentSession();
        sessao.merge(usuario);
    }
    
    public Usuario consultaPorCPF(String cpf) {
        Session sessao = HibernateUtil.getSessionFactory().getCurrentSession();
        Query consulta= sessao.createQuery("FROM Usuario WHERE cpf = :cpfConsulta");
        consulta.setString("cpfConsulta", cpf);
        return (Usuario) consulta.uniqueResult();
    }

    public Usuario consultaPorLoginESenha(String login, String senha) {
        Session sessao = HibernateUtil
                .getSessionFactory().getCurrentSession();
        Query consulta= sessao.createQuery(
                "FROM Usuario WHERE login = :login AND senha = :senha");
        consulta.setString("login", login);
        consulta.setString("senha", hashSenha(senha));
        return (Usuario) consulta.uniqueResult();

        
    }
}





