package persistencia;

import java.util.List;
import modelo.Livro;
import org.hibernate.Session;

public class LivroDAO {
    
    public void salvar(Livro livro) {
        Session sessao = HibernateUtil.getSessionFactory().getCurrentSession();
        if(livro.getId()>0)
            sessao.merge(livro);
        else
            sessao.saveOrUpdate(livro);
    }
    
    public Livro carregar(int id) {
        Session sessao = HibernateUtil.getSessionFactory().getCurrentSession();
        return (Livro) sessao.get(Livro.class, id);
    }
    
    public void remover(Livro livro) {
        Session sessao = HibernateUtil.getSessionFactory().getCurrentSession();
        sessao.delete(livro);
    }
    
    public List<Livro> listar() {
        Session sessao = HibernateUtil.getSessionFactory().getCurrentSession();
        return sessao.createCriteria(Livro.class).list();
    }
    
}
