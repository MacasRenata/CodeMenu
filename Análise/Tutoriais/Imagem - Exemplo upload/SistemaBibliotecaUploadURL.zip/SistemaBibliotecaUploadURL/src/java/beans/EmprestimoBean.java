package beans;

import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.List;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import modelo.Emprestimo;
import modelo.Livro;
import modelo.Usuario;
import persistencia.EmprestimoDAO;
import persistencia.LivroDAO;
import persistencia.UsuarioDAO;

@ManagedBean
@ViewScoped
public class EmprestimoBean {
private int idUsuario;
private int idLivro;
List<Emprestimo> listaEmprestimos = new ArrayList();;
EmprestimoDAO emprestimoDAO = new EmprestimoDAO();



    public int getIdLivro() {
        return idLivro;
    }

    public void setIdLivro(int idLivro) {
        this.idLivro = idLivro;
    }

    public int getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }

    public List<Emprestimo> getListaEmprestimos() {
        return listaEmprestimos;
    }
    
    public void adicionarLivro() {
        Emprestimo emprestimo = new Emprestimo();
        Livro livro = new LivroDAO().carregar(idLivro);
        Usuario usuario = new UsuarioDAO().carregar(idUsuario);
        String erro=null;
        if(livro==null)
            erro="Livro não cadastrado!";
         else
            if(livro.getEmprestimo()!=null)
                erro="Livro já reservado!";
        
        if(erro!=null) {
            FacesContext context = FacesContext.getCurrentInstance();
            context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, erro, ""));
        }
        else   {
        emprestimo.setLivro(livro);
        emprestimo.setUsuario(usuario);
        GregorianCalendar cal = new GregorianCalendar();
        emprestimo.setDataRetirada(cal.getTime());
        cal.add(GregorianCalendar.DAY_OF_MONTH, usuario.getDias());
        emprestimo.setDataDevolucao(cal.getTime());
        listaEmprestimos.add(emprestimo);
        }

    }

    public void salvarEmprestimo() {
        
        for (Emprestimo listaEmprestimo : listaEmprestimos) {
            emprestimoDAO.salvar(listaEmprestimo);
        }
    
    }
    
}


