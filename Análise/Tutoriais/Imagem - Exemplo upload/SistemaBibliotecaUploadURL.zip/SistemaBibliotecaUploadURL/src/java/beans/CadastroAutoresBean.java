package beans;

import java.util.List;
import javax.faces.application.FacesMessage;
import javax.faces.application.FacesMessage.Severity;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import modelo.Autor;
import persistencia.AutorDAO;

@ManagedBean(name="autorBean")
@ViewScoped
public class CadastroAutoresBean {
    private Autor autor = new Autor();
    private List<Autor> listaAutores;
    private AutorDAO autorDAO = new AutorDAO();
    
    public CadastroAutoresBean() {
        listaAutores = autorDAO.listar();
    }
    
    public Autor getAutor() {
        return autor;
    }

    public void setAutor(Autor autor) {
        this.autor = autor;
    }

    public List<Autor> getListaAutores() {
        return listaAutores;
    }

    public void setListaAutores(List<Autor> listaAutores) {
        this.listaAutores = listaAutores;
    }
    
    public void novoAutor() {
        autor = new Autor();
    }
    
    public String salvar() {
        boolean novo = autor.ehNovo();
        autorDAO.salvar(autor);
        if(novo) {
            listaAutores.add(autor);
            autor = new Autor();
            enviarMensagem(FacesMessage.SEVERITY_INFO, "Autor cadastrado com sucesso");
            return null;
        } else {
            enviarMensagem(FacesMessage.SEVERITY_INFO, "Autor atualizado com sucesso");
            return "consultaAutors1";
        }
        
    }
    
    public void carregar(int id) {
        autor = autorDAO.carregar(id);
    }
    
    public void remover(Autor autor) {
        autorDAO.remover(autor);
        enviarMensagem(FacesMessage.SEVERITY_INFO, "Autor removido com sucesso");
        listaAutores.remove(autor);
    }
    
    private void enviarMensagem(Severity sev, String msg) {
        FacesContext context = FacesContext.getCurrentInstance();
        context.addMessage(null, new FacesMessage(sev, msg, ""));
    }
    
}
