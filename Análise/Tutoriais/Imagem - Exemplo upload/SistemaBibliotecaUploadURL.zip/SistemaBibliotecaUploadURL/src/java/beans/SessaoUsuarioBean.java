package beans;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import modelo.Professor;
import modelo.Usuario;
import persistencia.UsuarioDAO;

@ManagedBean
@SessionScoped
public class SessaoUsuarioBean {
    private String login;
    private String senha;
    private Usuario usuarioLogado;
    
    
    public String fazerLogin() {
        usuarioLogado = dao.consultaPorLoginESenha(login, senha);
        if(usuarioLogado == null) {
            FacesContext.getCurrentInstance().addMessage(null, 
                    new FacesMessage(FacesMessage.SEVERITY_ERROR, 
                            "Login ou senha inválidos!", ""));
            return null;
        } else 
            return "index";
    }
    public String logout() {
        usuarioLogado = null;
        return "login";
    }
    public boolean temUsuarioLogado() {
        return usuarioLogado != null;
    }

    
    
    private UsuarioDAO dao = new UsuarioDAO();
    
    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public Usuario getUsuarioLogado() {
        return usuarioLogado;
    }

    public void setUsuarioLogado(Usuario usuarioLogado) {
        this.usuarioLogado = usuarioLogado;
    }
     public String getTipo(){
         if(usuarioLogado==null)
                 return null;
         else
            return (usuarioLogado instanceof Professor)?"professor":"aluno";
    } 
    
}
