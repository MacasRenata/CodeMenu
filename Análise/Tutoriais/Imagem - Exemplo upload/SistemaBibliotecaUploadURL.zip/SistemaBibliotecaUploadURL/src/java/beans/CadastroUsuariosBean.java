package beans;

import java.util.List;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import modelo.Aluno;
import modelo.Professor;
import modelo.Usuario;
import org.primefaces.context.RequestContext;
import persistencia.UsuarioDAO;

@ManagedBean(name="usuarioBean")
@ViewScoped
public class CadastroUsuariosBean {
    private Usuario usuario;
    String senha,resenha;
    private UsuarioDAO dao = new UsuarioDAO();
    private List<Usuario> listaUsuarios;

    public CadastroUsuariosBean() {
        listaUsuarios = dao.listar();
    }
    
    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }
    
    public List<Usuario> getListaUsuarios() {
        return listaUsuarios;
    }
    
    public void novoAluno() {
        usuario = new Aluno();
    }

    public void novoProfessor() {
        usuario = new Professor();
    }

    
    public void salvar() {
        boolean novo = usuario.isNovo();
        if(senha!=null&&!senha.isEmpty()) {
            if(!senha.equals(resenha)){
                erro("Senhas diferentes!");
                return;
            } else if(senha.length()<=6||!senha.matches(".*\\d.*") ){
                erro("Senha deve ter 6 ou mais caracteres e conter números!");
                return;
            } else {
                usuario.setSenha(UsuarioDAO.hashSenha(senha));
            }
                
        } else if(novo){
                erro("Novo usuário deve ter senha!");
                return;
            }
      Usuario usuarioBanco = dao.consultaPorCPF(usuario.getCpf());
        if(usuarioBanco == null || usuario.equals(usuarioBanco)) {
            if(novo)
                dao.salvar(usuario);
            else
                dao.merge(usuario);
            informacao("Usuário salvo com sucesso!");
            RequestContext.getCurrentInstance().execute("PF('dlgEdicaoUsuario').hide();");
            if(novo) {
                listaUsuarios.add(usuario);
                //usuario = new Usuario();
            }
        } else {
            erro("Já existe um usuário cadastrado com o CPF informado!");
        }
    }
    
    public void carregar(Usuario usuario) {
        this.usuario = usuario;
    }
    
    public void remover(Usuario usuario) {
        System.out.println("Teste!");
        dao.remover(usuario);
        listaUsuarios.remove(usuario);
        informacao("Usuário removido com sucesso!");
    }

    public void informacao(String mensagem) {
        FacesContext contexto = FacesContext.getCurrentInstance();
        contexto.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, mensagem,""));
    }
    
    public void erro(String mensagem) {
        FacesContext contexto = FacesContext.getCurrentInstance();
        contexto.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, mensagem,""));
    }
    
    public int getMatricula(){
        return (usuario instanceof Aluno)? ((Aluno)usuario).getMatricula():0;
    }
    
    public void setMatricula(int matricula){
        if((usuario instanceof Aluno))
            ((Aluno)usuario).setMatricula(matricula);
    }
    
    public String getDisciplina(){
        return (usuario instanceof Professor)? ((Professor)usuario).getDisciplina():null;
    }
    
    public void setDisciplina(String disciplina){
        if((usuario instanceof Professor))
            ((Professor)usuario).setDisciplina(disciplina);
    }
    
    
    public String getTipo(){
        return (usuario instanceof Aluno)?"aluno":"professor";
    } 

    public String getSenha() {
        return senha;
    }

    public String getResenha() {
        return resenha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public void setResenha(String resenha) {
        this.resenha = resenha;
    }

    
}
