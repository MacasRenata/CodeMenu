package beans;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import modelo.Autor;
import modelo.Livro;
import org.primefaces.context.RequestContext;
import org.primefaces.event.FileUploadEvent;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.StreamedContent;
import persistencia.AutorDAO;
import persistencia.LivroDAO;
import static servlet.ImageServlet.PATH_IMG;

@ManagedBean(name = "livrosBean")
@SessionScoped
public class CadastroLivrosBean {

    private Livro livro;
    private List<Livro> listaLivros;
    private LivroDAO dao = new LivroDAO();
    private AutorDAO autorDAO = new AutorDAO();
    
    byte[] imgCapa;
    String nomeArquivoCapa;

    private int idAutor;

    public String abrir() {
        listaLivros = dao.listar();
        livro = new Livro();
        return "livros";
    }

    public void setIdAutor(int idAutor) {
        this.idAutor = idAutor;
    }

    public int getIdAutor() {
        return idAutor;
    }

    public Livro getLivro() {
        return livro;
    }

    public void setLivro(Livro livro) {
        this.livro = livro;
    }

    public List<Livro> getListaLivros() {
        return listaLivros;
    }


    public void salvar() throws IOException {
        boolean novo = livro.isNovo();
        Autor autor = autorDAO.carregar(idAutor);
        livro.setAutor(autor);
        if (imgCapa != null) {
            int index = nomeArquivoCapa.lastIndexOf('.');
            String extension = "";
            if (index >= 0) 
                extension = nomeArquivoCapa.substring(index);
            String nomeArq = (Math.random()* 1000) 
                    + System.currentTimeMillis() + extension;
            File dir = new File( PATH_IMG + File.separator + "capas");
            if(!dir.exists())
                dir.mkdirs();
            FileOutputStream out = new FileOutputStream(new File(dir, nomeArq));
            out.write(imgCapa);
            out.close();
            livro.setUrlCapa(nomeArq);
        }

        dao.salvar(livro);
        informacao("Livro salvo com sucesso!");
        RequestContext.getCurrentInstance().execute("PF('dlgEdicaoLivro').hide();");
        if (novo) {
            listaLivros.add(livro);
            livro = new Livro();

        }
    }

    public void carregar(Livro livro) 
            throws SQLException {
        this.livro = livro;
        imgCapa = null;
        nomeArquivoCapa = null;
    }
    
    public void novoLivro() {
        livro = new Livro();
        imgCapa=null;
        nomeArquivoCapa=null;
    }


    public void remover(Livro livro) {
        dao.remover(livro);
        listaLivros.remove(livro);
        informacao("Livro removido com sucesso!");
    }

    public void upload(FileUploadEvent event) 
            throws IOException {
        imgCapa = new byte[(int) 
                event.getFile().getSize()];
        event.getFile().getInputstream().read(imgCapa);
        nomeArquivoCapa = event.getFile().getFileName();
    }
    
    public StreamedContent getCapa() throws IOException, SQLException {
        if (imgCapa != null) {
            return new DefaultStreamedContent(
                    new ByteArrayInputStream(imgCapa));
        } else if (livro.getUrlCapa() != null) {
            return new DefaultStreamedContent(
                    new FileInputStream(
                            PATH_IMG + File.separator + "capas"
                            + File.separator + livro.getUrlCapa()
                    ));
        }
        return null;
    }

    public void informacao(String mensagem) {
        FacesContext contexto = FacesContext.getCurrentInstance();
        contexto.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, mensagem, ""));
    }

}
