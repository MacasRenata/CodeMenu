package modelo;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="livros")
public class Livro implements Serializable {
    @Id
    @GeneratedValue
    private int id;
    private String titulo;
    private String sinopse;
    private int anoPublicacao;
    private String editora;
    private boolean doacao;
    
    private String urlCapa;
    
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name ="id_autor")
    private Autor autor;
    
    
    @OneToOne(mappedBy = "livro", fetch = FetchType.EAGER)
    private Emprestimo emprestimo;

    

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public void setAutor(Autor autor) {
        this.autor = autor;
    }

    public Autor getAutor() {
        return autor;
    }


    public String getSinopse() {
        return sinopse;
    }

    public void setSinopse(String sinopse) {
        this.sinopse = sinopse;
    }

    public int getAnoPublicacao() {
        return anoPublicacao;
    }

    public void setAnoPublicacao(int anoPublicacao) {
        this.anoPublicacao = anoPublicacao;
    }

    public String getEditora() {
        return editora;
    }

    public void setEditora(String editora) {
        this.editora = editora;
    }

    public boolean isDoacao() {
        return doacao;
    }

    public void setDoacao(boolean doacao) {
        this.doacao = doacao;
    }


    public Emprestimo getEmprestimo() {
        return emprestimo;
    }

    public String getUrlCapa() {
        return urlCapa;
    }

    public void setUrlCapa(String urlCapa) {
        this.urlCapa = urlCapa;
    }

    

    
    
    public String getReferenciaBibliografica() {
        String autorRef = "";
        if(autor != null) {
            String sobrenome = autor.getSobrenome().toUpperCase();
            autorRef = sobrenome + ", " + autor.getPrimeiroNome();
        }
        return autorRef + ". " + titulo + ". " + editora + ", " + anoPublicacao;
    }
    
    public boolean isNovo() {
        return id == 0;
    }
}
